<?php

return [
    "client_id" => env("GOOGLE_CLIENT_ID", null),
    "client_secret" => env("GOOGLE_CLIENT_SECRET", null),
    "refresh_token" => env("GOOGLE_REFRESH_TOKEN", null),
];
