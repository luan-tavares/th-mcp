<?php

namespace App\Handlers;

use Bref\LaravelBridge\Queue\QueueHandler;

class LaravelQueueHandler extends QueueHandler
{

}
